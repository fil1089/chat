import { useState } from "react";
import { ChatScreen } from "./components/ChatScreen";
import { LeftPanel } from "./components/LeftPanel";
import { RightPanel } from "./components/RightPanel";
import { SettingsScreen } from "./components/SettingsScreen";
import { HistoryScreen } from "./components/HistoryScreen";
import { AssistantsScreen } from "./components/AssistantsScreen";

type Screen = "chat" | "settings" | "history" | "assistants";

export default function App() {
  const [leftOpen, setLeftOpen] = useState(false);
  const [rightOpen, setRightOpen] = useState(false);
  const [selectedModel, setSelectedModel] = useState("gpt-4o-mini");
  const [activeScreen, setActiveScreen] = useState<Screen>("chat");

  const handleNavigate = (screen: Screen) => {
    setActiveScreen(screen);
  };

  const handleBack = () => {
    setActiveScreen("chat");
  };

  return (
    <div className="h-screen w-screen overflow-hidden bg-[#0a0a0c] max-w-[430px] mx-auto relative">
      {activeScreen === "chat" && (
        <ChatScreen
          onOpenLeft={() => setLeftOpen(true)}
          onOpenRight={() => setRightOpen(true)}
          selectedModel={selectedModel}
          onSelectModel={setSelectedModel}
        />
      )}
      {activeScreen === "settings" && (
        <SettingsScreen onBack={handleBack} onOpenMenu={() => setLeftOpen(true)} />
      )}
      {activeScreen === "history" && (
        <HistoryScreen onBack={handleBack} onOpenMenu={() => setLeftOpen(true)} />
      )}
      {activeScreen === "assistants" && (
        <AssistantsScreen onBack={handleBack} onOpenMenu={() => setLeftOpen(true)} />
      )}
      <LeftPanel
        open={leftOpen}
        onClose={() => setLeftOpen(false)}
        onNavigate={handleNavigate}
        activeScreen={activeScreen}
      />
      {activeScreen === "chat" && (
        <RightPanel
          open={rightOpen}
          onClose={() => setRightOpen(false)}
          selectedModel={selectedModel}
        />
      )}
    </div>
  );
}