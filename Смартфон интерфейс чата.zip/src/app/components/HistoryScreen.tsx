import { ArrowLeft, Clock, Plus } from "lucide-react";
import { motion } from "motion/react";
import { BlurBackground } from "./BlurBackground";

interface HistoryScreenProps {
  onBack: () => void;
  onOpenMenu?: () => void;
}

export function HistoryScreen({ onBack, onOpenMenu }: HistoryScreenProps) {
  return (
    <div className="flex flex-col h-full bg-[#0a0a0c] relative">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-white/[0.04] backdrop-blur-xl bg-[#0a0a0c]/70 relative z-10">
        <button
          onClick={onOpenMenu || onBack}
          className="p-2 -ml-2 text-[#8b8b9b] hover:text-white transition-colors"
        >
          <ArrowLeft size={22} />
        </button>
        <span className="text-white">Спроси ИИ</span>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col items-center px-4 relative">
        <div className="w-full max-w-md relative z-10">
          <motion.h2
            className="text-white text-center mt-8 mb-6"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            История
          </motion.h2>
          <div className="h-px bg-white/[0.04] mb-8" />
        </div>

        <BlurBackground variant="center" intensity="low" />

        <div className="flex-1 flex flex-col items-center justify-center px-6 -mt-16 relative z-10">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="w-16 h-16 rounded-full bg-[#7c5cfc]/10 border border-[#7c5cfc]/20 flex items-center justify-center mb-5 shadow-lg shadow-[#7c5cfc]/10">
              <Clock size={32} className="text-[#7c5cfc]" />
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.3 }}
          >
            <h3 className="text-white mb-2 text-center">История пуста</h3>
            <p className="text-[#6b6b7b] text-center text-sm mb-6">
              Начните чат, чтобы он появился в истории
            </p>
          </motion.div>
          <motion.button
            onClick={onBack}
            className="flex items-center gap-2 px-6 py-3 bg-[#7c5cfc] text-white rounded-xl hover:bg-[#6b4be0] transition-all shadow-lg shadow-[#7c5cfc]/20"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.4 }}
            whileTap={{ scale: 0.97 }}
          >
            <Plus size={18} />
            <span>Новый чат</span>
          </motion.button>
        </div>
      </div>
    </div>
  );
}
