import { X, FileText, Image, Paperclip } from "lucide-react";
import { motion } from "motion/react";

interface Message {
  id: string;
  preview: string;
  type: "user" | "assistant";
}

interface RightPanelProps {
  open: boolean;
  onClose: () => void;
  selectedModel: string;
}

const chatMessages: Message[] = [
  { id: "1", preview: "Как создать React проект?", type: "user" },
  { id: "2", preview: "Для создания React проекта используйте...", type: "assistant" },
  { id: "3", preview: "А как добавить Tailwind?", type: "user" },
  { id: "4", preview: "Установите Tailwind CSS с помощью...", type: "assistant" },
];

const modelInfo: Record<string, { name: string; description: string; cost: string }> = {
  "gpt-4o-mini": {
    name: "OpenAI: GPT-4o-mini",
    description:
      "Обрабатывает текст и изображения, понимает длинный контекст. Быстрая, экономичная, подходит для разработки, контент-генерации и образовательных задач.",
    cost: "12,59 ₽ / 50,36 ₽",
  },
  "gpt-4o": {
    name: "OpenAI: GPT-4o",
    description:
      "Флагманская мультимодальная модель. Понимает текст, изображения и аудио. Высокая точность, идеальна для сложных задач.",
    cost: "31,47 ₽ / 125,90 ₽",
  },
  "claude-3.5": {
    name: "Anthropic: Claude 3.5",
    description:
      "Продвинутая модель для анализа и генерации. Отличается безопасностью и точностью ответов.",
    cost: "18,90 ₽ / 94,50 ₽",
  },
  "deepseek-r1": {
    name: "DeepSeek: R1",
    description:
      "Модель с продвинутыми возможностями рассуждения. Отлично справляется с математикой и логикой.",
    cost: "6,93 ₽ / 27,72 ₽",
  },
};

export function RightPanel({ open, onClose, selectedModel }: RightPanelProps) {
  const model = modelInfo[selectedModel] || modelInfo["gpt-4o-mini"];

  return (
    <>
      {open && (
        <motion.div
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        />
      )}
      <motion.div
        className="fixed top-0 right-0 bottom-0 w-[85%] max-w-[320px] z-50 flex flex-col overflow-hidden"
        style={{
          background: "linear-gradient(180deg, #0d0d12 0%, #0a0a0e 100%)",
        }}
        initial={{ x: "100%" }}
        animate={{ x: open ? 0 : "100%" }}
        transition={{ type: "spring", damping: 25, stiffness: 300 }}
      >
        {/* Purple glow at top */}
        <div
          className="absolute top-0 left-0 right-0 h-40 pointer-events-none"
          style={{
            background:
              "radial-gradient(ellipse at top center, rgba(124,92,252,0.08) 0%, transparent 70%)",
          }}
        />

        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-white/[0.04] relative z-10">
          <span className="text-[#6b6b7b] text-sm uppercase tracking-wider">
            Модель
          </span>
          <button
            className="p-1.5 text-[#6b6b7b] hover:text-white transition-colors"
            onClick={onClose}
          >
            <X size={20} />
          </button>
        </div>

        {/* Model Info */}
        <motion.div
          className="p-4 space-y-3 border-b border-white/[0.04] relative z-10"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: open ? 1 : 0, y: open ? 0 : 10 }}
          transition={{ delay: 0.15 }}
        >
          <h3 className="text-white">{model.name}</h3>
          <p className="text-[#8b8b9b] text-sm leading-relaxed">
            {model.description}
          </p>
          <div className="flex items-center justify-between text-sm">
            <span className="text-[#6b6b7b]">Стоимость (1M):</span>
            <span className="text-white/90">{model.cost}</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-[#6b6b7b]">Возможности:</span>
            <div className="flex items-center gap-2">
              {[FileText, Image, Paperclip].map((Icon, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, scale: 0 }}
                  animate={{ opacity: open ? 1 : 0, scale: open ? 1 : 0 }}
                  transition={{ delay: 0.3 + i * 0.1 }}
                >
                  <Icon size={14} className="text-[#7c5cfc]/60" />
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Chat Navigation */}
        <div className="p-4 relative z-10">
          <h4 className="text-[#6b6b7b] text-sm uppercase tracking-wider mb-3">
            Содержание беседы
          </h4>
          {chatMessages.length > 0 ? (
            <div className="space-y-1.5">
              {chatMessages.map((msg, i) => (
                <motion.button
                  key={msg.id}
                  className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-white/[0.04] transition-all border border-transparent hover:border-white/[0.06]"
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: open ? 1 : 0, x: open ? 0 : 10 }}
                  transition={{ delay: 0.2 + i * 0.05 }}
                >
                  <span
                    className={`text-sm ${
                      msg.type === "user" ? "text-[#7c5cfc]" : "text-white/60"
                    }`}
                  >
                    {msg.preview}
                  </span>
                </motion.button>
              ))}
            </div>
          ) : (
            <p className="text-[#6b6b7b] text-sm">
              Тут появится история ваших сообщений
            </p>
          )}
        </div>
      </motion.div>
    </>
  );
}
