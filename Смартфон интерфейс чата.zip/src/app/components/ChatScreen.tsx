import { useState, useRef, useEffect } from "react";
import {
  Menu,
  PanelRight,
  ChevronUp,
  Send,
  Paperclip,
  Settings,
  Sparkles,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { BlurBackground } from "./BlurBackground";

interface Message {
  id: string;
  text: string;
  role: "user" | "assistant";
}

interface Model {
  id: string;
  name: string;
  tag?: string;
}

const models: Model[] = [
  { id: "gpt-4o-mini", name: "GPT-4o-mini", tag: "АКТУАЛЬНАЯ" },
  { id: "gpt-4o", name: "GPT-4o" },
  { id: "claude-3.5", name: "Claude 3.5 Sonnet" },
  { id: "deepseek-r1", name: "DeepSeek R1" },
];

interface ChatScreenProps {
  onOpenLeft: () => void;
  onOpenRight: () => void;
  selectedModel: string;
  onSelectModel: (id: string) => void;
}

export function ChatScreen({
  onOpenLeft,
  onOpenRight,
  selectedModel,
  onSelectModel,
}: ChatScreenProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [showModelPicker, setShowModelPicker] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const currentModel = models.find((m) => m.id === selectedModel) || models[0];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = () => {
    if (!input.trim()) return;
    const userMsg: Message = {
      id: Date.now().toString(),
      text: input.trim(),
      role: "user",
    };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsTyping(true);

    setTimeout(() => {
      setIsTyping(false);
      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        text: `Это демо-ответ от ${currentModel.name}. В реальном приложении здесь будет ответ от ИИ модели.`,
        role: "assistant",
      };
      setMessages((prev) => [...prev, aiMsg]);
    }, 1500);
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0a0c] relative">
      {/* Header with glass effect */}
      <div className="relative z-20 flex items-center justify-between px-4 py-3 border-b border-white/5 backdrop-blur-xl bg-[#0a0a0c]/70">
        <button
          onClick={onOpenLeft}
          className="p-2 -ml-2 text-[#8b8b9b] hover:text-white transition-colors"
        >
          <Menu size={22} />
        </button>
        <motion.div
          className="flex items-center gap-2"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <motion.div
            animate={{ rotate: [0, 360] }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          >
            <Sparkles size={16} className="text-[#7c5cfc]" />
          </motion.div>
          <span className="text-white">Спроси ИИ</span>
        </motion.div>
        <button
          onClick={onOpenRight}
          className="p-2 -mr-2 text-[#8b8b9b] hover:text-white transition-colors"
        >
          <PanelRight size={22} />
        </button>
      </div>

      {/* Chat Area */}
      <div className="flex-1 overflow-y-auto px-4 relative">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center px-4 relative">
            {/* Blur Background Effect */}
            <BlurBackground variant="full" intensity="medium" />

            {/* Title with fade-in */}
            <motion.div
              className="relative z-10 mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
            >
              <h1
                className="text-white/90 mb-3"
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontWeight: 300,
                  lineHeight: "1.2",
                }}
              >
                Начните
                <br />
                <span className="text-[#7c5cfc]">диалог</span>
              </h1>
              <motion.p
                className="text-[#6b6b7b] text-sm"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.6, delay: 0.8 }}
              >
                Выберите модель и отправьте сообщение
              </motion.p>
            </motion.div>

            {/* Suggestion cards with stagger animation */}
            <motion.div
              className="flex gap-3 w-full overflow-x-auto pb-2 no-scrollbar relative z-10"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 1.0 }}
            >
              {[
                { title: "Создай иллюстрацию", sub: "для пекарни" },
                { title: "Создай план занятий", sub: "для тренировок" },
                { title: "Напиши код", sub: "на Python" },
              ].map((card, i) => (
                <motion.button
                  key={i}
                  className="min-w-[150px] bg-white/[0.04] backdrop-blur-sm border border-white/[0.06] rounded-2xl p-4 text-left shrink-0 hover:bg-white/[0.08] hover:border-[#7c5cfc]/20 transition-all group"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: 1.2 + i * 0.15 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => {
                    setInput(card.title + " " + card.sub);
                  }}
                >
                  <p className="text-white/80 text-sm group-hover:text-white transition-colors">
                    {card.title}
                  </p>
                  <p className="text-[#6b6b7b] text-xs mt-1 group-hover:text-[#7c5cfc]/60 transition-colors">
                    {card.sub}
                  </p>
                </motion.button>
              ))}
            </motion.div>
          </div>
        ) : (
          <div className="py-4 space-y-4 relative z-10">
            <AnimatePresence>
              {messages.map((msg) => (
                <motion.div
                  key={msg.id}
                  className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                  initial={{ opacity: 0, y: 15, scale: 0.97 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  transition={{ duration: 0.3, ease: "easeOut" }}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl px-4 py-3 ${
                      msg.role === "user"
                        ? "bg-[#7c5cfc] text-white shadow-lg shadow-[#7c5cfc]/20"
                        : "bg-white/[0.06] backdrop-blur-sm border border-white/[0.06] text-white/90"
                    }`}
                  >
                    <p className="text-sm leading-relaxed">{msg.text}</p>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            {/* Typing indicator */}
            <AnimatePresence>
              {isTyping && (
                <motion.div
                  className="flex justify-start"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                >
                  <div className="bg-white/[0.06] backdrop-blur-sm border border-white/[0.06] rounded-2xl px-4 py-3 flex gap-1.5">
                    {[0, 1, 2].map((i) => (
                      <motion.div
                        key={i}
                        className="w-2 h-2 rounded-full bg-[#7c5cfc]"
                        animate={{
                          opacity: [0.3, 1, 0.3],
                          scale: [0.8, 1, 0.8],
                        }}
                        transition={{
                          duration: 1,
                          repeat: Infinity,
                          delay: i * 0.2,
                        }}
                      />
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* Input Area with glass effect */}
      <div className="relative z-20 px-4 pb-6 pt-2">
        {/* Gradient fade above input */}
        <div className="absolute -top-8 left-0 right-0 h-8 bg-gradient-to-t from-[#0a0a0c] to-transparent pointer-events-none" />

        {/* Model Selector */}
        <div className="relative mb-2">
          <motion.button
            onClick={() => setShowModelPicker(!showModelPicker)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg hover:bg-white/[0.04] transition-colors"
            whileTap={{ scale: 0.97 }}
          >
            <span className="text-white/90 text-sm">{currentModel.name}</span>
            {currentModel.tag && (
              <span className="text-[10px] bg-[#7c5cfc]/20 text-[#7c5cfc] px-1.5 py-0.5 rounded">
                {currentModel.tag}
              </span>
            )}
            <ChevronUp
              size={14}
              className={`text-[#6b6b7b] transition-transform duration-200 ${
                showModelPicker ? "" : "rotate-180"
              }`}
            />
          </motion.button>

          <AnimatePresence>
            {showModelPicker && (
              <motion.div
                initial={{ opacity: 0, y: 10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 10, scale: 0.95 }}
                transition={{ duration: 0.2 }}
                className="absolute bottom-full left-0 mb-2 w-64 bg-[#141418]/95 backdrop-blur-xl border border-white/[0.08] rounded-2xl overflow-hidden shadow-2xl shadow-black/50 z-10"
              >
                {models.map((model, i) => (
                  <motion.button
                    key={model.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.05 }}
                    onClick={() => {
                      onSelectModel(model.id);
                      setShowModelPicker(false);
                    }}
                    className={`flex items-center gap-2 w-full px-4 py-3 text-left transition-all ${
                      model.id === selectedModel
                        ? "bg-[#7c5cfc]/10 text-[#7c5cfc]"
                        : "text-white/80 hover:bg-white/[0.04]"
                    }`}
                  >
                    <span className="text-sm">{model.name}</span>
                    {model.tag && (
                      <span className="text-[9px] bg-[#7c5cfc]/20 text-[#7c5cfc] px-1.5 py-0.5 rounded">
                        {model.tag}
                      </span>
                    )}
                  </motion.button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Text Input with glass */}
        <div className="flex items-end gap-2 bg-white/[0.04] backdrop-blur-sm border border-white/[0.08] rounded-2xl px-3 py-2 focus-within:border-[#7c5cfc]/30 transition-colors">
          <button className="p-2 text-[#6b6b7b] hover:text-[#7c5cfc] transition-colors shrink-0">
            <Paperclip size={18} />
          </button>
          <textarea
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="Введите сообщение..."
            rows={1}
            className="flex-1 bg-transparent border-none outline-none text-white/90 placeholder:text-[#4a4a5a] resize-none min-h-[24px] max-h-[120px] py-1.5"
          />
          <button className="p-2 text-[#6b6b7b] hover:text-[#7c5cfc] transition-colors shrink-0">
            <Settings size={18} />
          </button>
          <motion.button
            onClick={handleSend}
            className={`p-2 rounded-xl shrink-0 transition-all ${
              input.trim()
                ? "bg-[#7c5cfc] text-white shadow-lg shadow-[#7c5cfc]/30"
                : "bg-white/[0.06] text-[#4a4a5a]"
            }`}
            whileTap={{ scale: 0.9 }}
          >
            <Send size={18} />
          </motion.button>
        </div>
      </div>
    </div>
  );
}
