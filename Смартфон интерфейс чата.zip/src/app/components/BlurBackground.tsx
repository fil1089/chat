import { motion } from "motion/react";

interface BlurBackgroundProps {
  variant?: "full" | "top" | "center";
  intensity?: "low" | "medium" | "high";
}

export function BlurBackground({ variant = "full", intensity = "medium" }: BlurBackgroundProps) {
  const opacityMap = { low: 0.3, medium: 0.5, high: 0.7 };
  const op = opacityMap[intensity];

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Noise texture overlay */}
      <div
        className="absolute inset-0 opacity-[0.03] z-10"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")`,
        }}
      />

      {variant === "full" && (
        <>
          {/* Main arc glow - purple */}
          <motion.div
            className="absolute"
            style={{
              bottom: "15%",
              left: "50%",
              width: "140%",
              height: "60%",
              transform: "translateX(-50%)",
              borderRadius: "50%",
              background: `radial-gradient(ellipse at center, rgba(124,92,252,${op * 0.4}) 0%, rgba(124,92,252,${op * 0.15}) 30%, transparent 70%)`,
              filter: "blur(40px)",
            }}
            animate={{
              opacity: [0.6, 1, 0.6],
              scale: [0.98, 1.02, 0.98],
            }}
            transition={{
              duration: 6,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />

          {/* Arc line */}
          <svg
            className="absolute bottom-[15%] left-1/2 -translate-x-1/2"
            width="120%"
            height="200"
            viewBox="0 0 500 200"
            fill="none"
            style={{ marginLeft: "-10%" }}
          >
            <motion.path
              d="M-50 180 Q250 -20 550 180"
              stroke="url(#arcGradient)"
              strokeWidth="2.5"
              strokeLinecap="round"
              fill="none"
              initial={{ pathLength: 0, opacity: 0 }}
              animate={{ pathLength: 1, opacity: 1 }}
              transition={{ duration: 2, ease: "easeOut" }}
            />
            <defs>
              <linearGradient id="arcGradient" x1="0" y1="0" x2="500" y2="0" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="rgba(124,92,252,0.1)" />
                <stop offset="30%" stopColor="rgba(124,92,252,0.8)" />
                <stop offset="50%" stopColor="rgba(160,120,255,1)" />
                <stop offset="70%" stopColor="rgba(124,92,252,0.8)" />
                <stop offset="100%" stopColor="rgba(124,92,252,0.1)" />
              </linearGradient>
            </defs>
          </svg>

          {/* Left dispersion ray */}
          <motion.div
            className="absolute"
            style={{
              bottom: "30%",
              left: "-5%",
              width: "50%",
              height: "70%",
              background: `radial-gradient(ellipse at bottom left, rgba(124,92,252,${op * 0.25}) 0%, transparent 60%)`,
              filter: "blur(50px)",
              transformOrigin: "bottom left",
            }}
            animate={{
              opacity: [0.4, 0.7, 0.4],
              rotate: [-2, 2, -2],
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />

          {/* Right dispersion ray */}
          <motion.div
            className="absolute"
            style={{
              bottom: "30%",
              right: "-5%",
              width: "50%",
              height: "70%",
              background: `radial-gradient(ellipse at bottom right, rgba(124,92,252,${op * 0.25}) 0%, transparent 60%)`,
              filter: "blur(50px)",
              transformOrigin: "bottom right",
            }}
            animate={{
              opacity: [0.4, 0.7, 0.4],
              rotate: [2, -2, 2],
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 1,
            }}
          />

          {/* Top center glow */}
          <motion.div
            className="absolute"
            style={{
              top: "-20%",
              left: "50%",
              width: "80%",
              height: "60%",
              transform: "translateX(-50%)",
              background: `radial-gradient(ellipse at center, rgba(124,92,252,${op * 0.2}) 0%, transparent 70%)`,
              filter: "blur(60px)",
            }}
            animate={{
              opacity: [0.3, 0.6, 0.3],
            }}
            transition={{
              duration: 5,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 2,
            }}
          />
        </>
      )}

      {variant === "top" && (
        <motion.div
          className="absolute"
          style={{
            top: "-30%",
            left: "50%",
            width: "120%",
            height: "70%",
            transform: "translateX(-50%)",
            background: `radial-gradient(ellipse at center top, rgba(124,92,252,${op * 0.3}) 0%, transparent 60%)`,
            filter: "blur(40px)",
          }}
          animate={{
            opacity: [0.5, 0.8, 0.5],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      )}

      {variant === "center" && (
        <motion.div
          className="absolute"
          style={{
            top: "30%",
            left: "50%",
            width: "100%",
            height: "50%",
            transform: "translateX(-50%)",
            borderRadius: "50%",
            background: `radial-gradient(ellipse at center, rgba(124,92,252,${op * 0.2}) 0%, transparent 60%)`,
            filter: "blur(50px)",
          }}
          animate={{
            opacity: [0.3, 0.6, 0.3],
            scale: [0.95, 1.05, 0.95],
          }}
          transition={{
            duration: 6,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      )}

      {/* Animated particles */}
      {[...Array(6)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full"
          style={{
            width: 2 + Math.random() * 3,
            height: 1,
            background: `rgba(124,92,252,${0.3 + Math.random() * 0.4})`,
            top: `${10 + Math.random() * 80}%`,
            left: `${Math.random() * 100}%`,
          }}
          animate={{
            x: [0, 20 + Math.random() * 40, 0],
            opacity: [0, 0.8, 0],
          }}
          transition={{
            duration: 3 + Math.random() * 4,
            repeat: Infinity,
            ease: "easeInOut",
            delay: Math.random() * 5,
          }}
        />
      ))}
    </div>
  );
}
