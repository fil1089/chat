import { useState } from "react";
import {
  Search,
  X,
  Bot,
  Settings as SettingsIcon,
  Clock,
  Plus,
  User,
} from "lucide-react";
import { motion } from "motion/react";

interface Chat {
  id: string;
  title: string;
  active?: boolean;
}

interface LeftPanelProps {
  open: boolean;
  onClose: () => void;
  onNavigate: (screen: "chat" | "settings" | "history" | "assistants") => void;
  activeScreen: string;
}

const chats: Chat[] = [
  { id: "1", title: "Запуск React Vite проекта", active: true },
  { id: "2", title: "Шрифт с кириллицей" },
  { id: "3", title: "Анализ композиции еды" },
  { id: "4", title: "Неясное сообщение пользов..." },
  { id: "5", title: "Весенний стиль аватара" },
  { id: "6", title: "Аватар в весеннем стиле" },
];

export function LeftPanel({ open, onClose, onNavigate, activeScreen }: LeftPanelProps) {
  const [searchValue, setSearchValue] = useState("");

  const handleNav = (screen: "chat" | "settings" | "history" | "assistants") => {
    onNavigate(screen);
    onClose();
  };

  return (
    <>
      {open && (
        <motion.div
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        />
      )}
      <motion.div
        className="fixed top-0 left-0 bottom-0 w-[85%] max-w-[320px] z-50 flex flex-col overflow-hidden"
        style={{
          background: "linear-gradient(180deg, #0d0d12 0%, #0a0a0e 100%)",
        }}
        initial={{ x: "-100%" }}
        animate={{ x: open ? 0 : "-100%" }}
        transition={{ type: "spring", damping: 25, stiffness: 300 }}
      >
        {/* Purple glow at top */}
        <div
          className="absolute top-0 left-0 right-0 h-40 pointer-events-none"
          style={{
            background:
              "radial-gradient(ellipse at top center, rgba(124,92,252,0.08) 0%, transparent 70%)",
          }}
        />

        {/* Header */}
        <div className="flex items-center justify-between p-4 pb-2 relative z-10">
          <motion.span
            className="text-white"
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: open ? 1 : 0, x: open ? 0 : -10 }}
            transition={{ delay: 0.15 }}
          >
            Спроси ИИ
          </motion.span>
          <button
            className="p-2 text-[#8b8b9b] hover:text-white transition-colors"
            onClick={onClose}
          >
            <X size={20} />
          </button>
        </div>

        {/* New Chat Button */}
        <motion.div
          className="px-4 py-2 relative z-10"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: open ? 1 : 0, y: open ? 0 : 10 }}
          transition={{ delay: 0.2 }}
        >
          <button
            onClick={() => handleNav("chat")}
            className="flex items-center gap-2 w-full px-4 py-2.5 bg-[#7c5cfc] text-white rounded-xl hover:bg-[#6b4be0] transition-all shadow-lg shadow-[#7c5cfc]/20 active:scale-[0.98]"
          >
            <Plus size={18} />
            <span>Новый чат</span>
          </button>
        </motion.div>

        {/* Navigation */}
        <div className="px-4 py-2 space-y-0.5 relative z-10">
          {[
            { id: "assistants" as const, icon: Bot, label: "ИИ Помощники" },
            { id: "history" as const, icon: Clock, label: "История" },
          ].map((item, i) => (
            <motion.button
              key={item.id}
              onClick={() => handleNav(item.id)}
              className={`flex items-center gap-3 w-full px-3 py-2.5 rounded-xl transition-all ${
                activeScreen === item.id
                  ? "bg-[#7c5cfc]/10 text-white border border-[#7c5cfc]/20"
                  : "text-white/70 hover:bg-white/[0.04]"
              }`}
              initial={{ opacity: 0, x: -15 }}
              animate={{ opacity: open ? 1 : 0, x: open ? 0 : -15 }}
              transition={{ delay: 0.25 + i * 0.05 }}
            >
              <item.icon
                size={18}
                className={activeScreen === item.id ? "text-[#7c5cfc]" : "text-[#9b9bab]"}
              />
              <span>{item.label}</span>
            </motion.button>
          ))}
        </div>

        {/* Search */}
        <motion.div
          className="px-4 py-2 relative z-10"
          initial={{ opacity: 0 }}
          animate={{ opacity: open ? 1 : 0 }}
          transition={{ delay: 0.35 }}
        >
          <div className="flex items-center gap-2 bg-white/[0.04] border border-white/[0.06] rounded-xl px-3 py-2.5 focus-within:border-[#7c5cfc]/30 transition-colors">
            <Search size={16} className="text-[#6b6b7b] shrink-0" />
            <input
              type="text"
              placeholder="Поиск чатов..."
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
              className="bg-transparent border-none outline-none text-white/90 placeholder:text-[#6b6b7b] w-full"
            />
          </div>
        </motion.div>

        {/* Chats label */}
        <div className="px-7 pt-3 pb-1 relative z-10">
          <span className="text-[#6b6b7b] text-xs uppercase tracking-wider">
            Чаты
          </span>
        </div>

        {/* Chats */}
        <div className="flex-1 overflow-y-auto px-4 space-y-0.5 relative z-10">
          {chats.map((chat, i) => (
            <motion.button
              key={chat.id}
              onClick={() => handleNav("chat")}
              className={`flex items-center w-full px-3 py-3 rounded-xl transition-all ${
                chat.active
                  ? "bg-white/[0.06] text-white border border-white/[0.06]"
                  : "text-white/60 hover:bg-white/[0.03] hover:text-white/80"
              }`}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: open ? 1 : 0, x: open ? 0 : -10 }}
              transition={{ delay: 0.35 + i * 0.04 }}
            >
              <span className="truncate">{chat.title}</span>
            </motion.button>
          ))}
        </div>

        {/* Bottom */}
        <div className="p-4 space-y-1 border-t border-white/[0.04] relative z-10">
          <button
            onClick={() => handleNav("settings")}
            className={`flex items-center gap-3 w-full px-3 py-2.5 rounded-xl transition-all ${
              activeScreen === "settings"
                ? "bg-[#7c5cfc]/10 text-white border border-[#7c5cfc]/20"
                : "text-white/70 hover:bg-white/[0.04]"
            }`}
          >
            <SettingsIcon
              size={18}
              className={activeScreen === "settings" ? "text-[#7c5cfc]" : "text-[#6b6b7b]"}
            />
            <span>Настройки</span>
          </button>
          <button className="flex items-center gap-3 w-full px-3 py-2.5 rounded-xl text-white/70 hover:bg-white/[0.04] transition-all">
            <User size={18} className="text-[#6b6b7b]" />
            <span>Войти</span>
          </button>
        </div>
      </motion.div>
    </>
  );
}
