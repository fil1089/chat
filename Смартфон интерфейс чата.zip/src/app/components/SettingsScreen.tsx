import { useState } from "react";
import { motion } from "motion/react";
import {
  ArrowLeft,
  Settings,
  Eye,
  EyeOff,
  RefreshCw,
  ChevronDown,
} from "lucide-react";

interface SettingsScreenProps {
  onBack: () => void;
  onOpenMenu?: () => void;
}

export function SettingsScreen({ onBack, onOpenMenu }: SettingsScreenProps) {
  const [apiProvider, setApiProvider] = useState("polza");
  const [apiKey, setApiKey] = useState("sk-xxxxxxxx");
  const [showKey, setShowKey] = useState(false);
  const [defaultModel, setDefaultModel] = useState("gpt-4o-mini");
  const [showProviderDropdown, setShowProviderDropdown] = useState(false);
  const [showModelDropdown, setShowModelDropdown] = useState(false);

  const providers = [
    { id: "polza", name: "Polza API" },
    { id: "openai", name: "OpenAI API" },
    { id: "anthropic", name: "Anthropic API" },
  ];

  const models = [
    { id: "gpt-4o-mini", name: "OpenAI: GPT-4o-mini", tag: "АКТУАЛЬНАЯ" },
    { id: "gpt-4o", name: "OpenAI: GPT-4o" },
    { id: "claude-3.5", name: "Anthropic: Claude 3.5" },
    { id: "deepseek-r1", name: "DeepSeek: R1" },
  ];

  const currentProvider = providers.find((p) => p.id === apiProvider);
  const currentModel = models.find((m) => m.id === defaultModel);

  return (
    <div className="flex flex-col h-full bg-[#0a0a0c] relative">
      {/* Background glow */}
      <div
        className="absolute top-0 left-0 right-0 h-60 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse at top center, rgba(124,92,252,0.06) 0%, transparent 70%)",
        }}
      />

      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-white/[0.04] backdrop-blur-xl bg-[#0a0a0c]/70 relative z-10">
        <button
          onClick={onOpenMenu || onBack}
          className="p-2 -ml-2 text-[#8b8b9b] hover:text-white transition-colors"
        >
          <ArrowLeft size={22} />
        </button>
        <span className="text-white">Спроси ИИ</span>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-4 py-6 relative z-10">
        <motion.div
          className="flex items-center gap-3 mb-6"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <Settings size={24} className="text-[#7c5cfc]" />
          <h2 className="text-white">Настройки</h2>
        </motion.div>

        {/* API Configuration */}
        <motion.div
          className="bg-white/[0.03] backdrop-blur-sm border border-white/[0.06] rounded-2xl p-4 mb-4"
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
        >
          <h3 className="text-white mb-4">API Конфигурация</h3>

          {/* Provider */}
          <div className="mb-4">
            <label className="text-[#6b6b7b] text-sm mb-2 block">
              Провайдер API
            </label>
            <div className="relative">
              <button
                onClick={() => setShowProviderDropdown(!showProviderDropdown)}
                className="w-full flex items-center justify-between bg-[#0a0a0c]/60 border border-white/[0.08] rounded-xl px-4 py-3 text-white/90"
              >
                <span>{currentProvider?.name}</span>
                <ChevronDown
                  size={16}
                  className={`text-[#6b6b7b] transition-transform ${
                    showProviderDropdown ? "rotate-180" : ""
                  }`}
                />
              </button>
              {showProviderDropdown && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-[#141418]/95 backdrop-blur-xl border border-white/[0.08] rounded-xl overflow-hidden z-10 shadow-2xl shadow-black/50">
                  {providers.map((p) => (
                    <button
                      key={p.id}
                      onClick={() => {
                        setApiProvider(p.id);
                        setShowProviderDropdown(false);
                      }}
                      className={`w-full text-left px-4 py-3 transition-colors ${
                        p.id === apiProvider
                          ? "bg-[#7c5cfc]/10 text-[#7c5cfc]"
                          : "text-white/80 hover:bg-white/[0.04]"
                      }`}
                    >
                      {p.name}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* API Key */}
          <div className="mb-3">
            <label className="text-[#6b6b7b] text-sm mb-2 block">
              API Ключ ({currentProvider?.name})
            </label>
            <div className="flex items-center gap-2">
              <div className="flex-1 flex items-center bg-[#0a0a0c]/60 border border-white/[0.08] rounded-xl px-4 py-3">
                <input
                  type={showKey ? "text" : "password"}
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  className="flex-1 bg-transparent border-none outline-none text-white/90"
                />
                <button
                  onClick={() => setShowKey(!showKey)}
                  className="text-[#6b6b7b] hover:text-white ml-2 transition-colors"
                >
                  {showKey ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
              <button className="px-4 py-3 bg-[#7c5cfc] text-white rounded-xl hover:bg-[#6b4be0] transition-all shadow-lg shadow-[#7c5cfc]/20 shrink-0">
                Проверить
              </button>
            </div>
          </div>

          <p className="text-[#6b6b7b] text-sm">
            Получить ключ на{" "}
            <span className="text-[#7c5cfc] underline">polza.ai</span>
          </p>

          <div className="mt-4 pt-4 border-t border-white/[0.06]">
            <p className="text-[#6b6b7b] text-sm mb-1">Баланс Polza.ai</p>
            <div className="flex items-center gap-2">
              <span className="text-white text-lg">0.00 ₽</span>
              <button className="text-[#6b6b7b] hover:text-white transition-colors">
                <RefreshCw size={14} />
              </button>
            </div>
          </div>
        </motion.div>

        {/* Default Parameters */}
        <motion.div
          className="bg-white/[0.03] backdrop-blur-sm border border-white/[0.06] rounded-2xl p-4 mb-4"
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.2 }}
        >
          <h3 className="text-white mb-4">Параметры по умолчанию</h3>

          <div>
            <label className="text-[#6b6b7b] text-sm mb-2 block">
              Модель по умолчанию
            </label>
            <div className="relative">
              <button
                onClick={() => setShowModelDropdown(!showModelDropdown)}
                className="w-full flex items-center justify-between bg-[#0a0a0c]/60 border border-white/[0.08] rounded-xl px-4 py-3"
              >
                <div className="flex items-center gap-2">
                  <span className="text-white/90">{currentModel?.name}</span>
                  {currentModel?.tag && (
                    <span className="text-[9px] bg-[#7c5cfc]/20 text-[#7c5cfc] px-1.5 py-0.5 rounded">
                      {currentModel.tag}
                    </span>
                  )}
                </div>
                <ChevronDown
                  size={16}
                  className={`text-[#6b6b7b] transition-transform ${
                    showModelDropdown ? "rotate-180" : ""
                  }`}
                />
              </button>
              {showModelDropdown && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-[#141418]/95 backdrop-blur-xl border border-white/[0.08] rounded-xl overflow-hidden z-10 shadow-2xl shadow-black/50">
                  {models.map((m) => (
                    <button
                      key={m.id}
                      onClick={() => {
                        setDefaultModel(m.id);
                        setShowModelDropdown(false);
                      }}
                      className={`w-full text-left px-4 py-3 flex items-center gap-2 transition-colors ${
                        m.id === defaultModel
                          ? "bg-[#7c5cfc]/10 text-[#7c5cfc]"
                          : "text-white/80 hover:bg-white/[0.04]"
                      }`}
                    >
                      <span className="text-sm">{m.name}</span>
                      {m.tag && (
                        <span className="text-[9px] bg-[#7c5cfc]/20 text-[#7c5cfc] px-1.5 py-0.5 rounded">
                          {m.tag}
                        </span>
                      )}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </motion.div>

        {/* Data */}
        <motion.div
          className="bg-white/[0.03] backdrop-blur-sm border border-white/[0.06] rounded-2xl p-4"
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.3 }}
        >
          <h3 className="text-white mb-4">Данные</h3>

          <div className="flex items-center gap-4 mb-4 text-[#6b6b7b] text-sm">
            <span>📄 0 чатов</span>
            <span>📁 0 пространств</span>
          </div>

          <div className="flex flex-wrap gap-2">
            <button className="px-4 py-2.5 bg-[#0a0a0c]/60 border border-white/[0.08] rounded-xl text-white/80 hover:bg-white/[0.04] transition-all text-sm">
              Экспорт данных
            </button>
            <button className="px-4 py-2.5 bg-[#0a0a0c]/60 border border-white/[0.08] rounded-xl text-white/80 hover:bg-white/[0.04] transition-all text-sm">
              Импорт данных
            </button>
            <button className="px-4 py-2.5 bg-red-500/10 border border-red-500/20 rounded-xl text-red-400 hover:bg-red-500/20 transition-all text-sm">
              Очистить все данные
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}